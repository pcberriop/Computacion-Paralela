/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unalcol.math.metric;

import unalcol.math.algebra.VectorSpace;

/**
 *
 * @author jgomez
 */
public interface MetricVectorSpace<T> extends VectorSpace<T>, QuasiMetric<T> {    
}
