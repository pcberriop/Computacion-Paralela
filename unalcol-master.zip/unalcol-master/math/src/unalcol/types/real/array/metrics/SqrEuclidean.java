/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unalcol.types.real.array.metrics;

/**
 *
 * @author jgomez
 */
public class SqrEuclidean extends PMinkowski{
    public SqrEuclidean(){
        super(2.0);
    }
}
