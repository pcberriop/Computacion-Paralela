/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package unalcol.gui.paint;
import java.awt.Graphics2D;

/**
 *
 * @author jgomez
 */
public abstract class ShapeDrawer {

    public abstract void draw( Graphics2D g, Shape shape );

}
