package unalcol.data.oodb;

public interface OODBTable<T> {
	public T get( int i );
}