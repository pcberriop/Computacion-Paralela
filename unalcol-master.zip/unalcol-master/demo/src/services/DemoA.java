package services;

public class DemoA {
	public String toString(){
		return "A";
	}
}
