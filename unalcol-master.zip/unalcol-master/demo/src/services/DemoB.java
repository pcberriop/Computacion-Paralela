package services;

public class DemoB extends DemoA{
	public DemoB(){}
	public String toString(){
		return "B";
	}
}
