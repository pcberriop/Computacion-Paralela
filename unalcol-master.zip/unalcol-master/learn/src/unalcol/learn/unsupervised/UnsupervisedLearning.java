/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unalcol.learn.unsupervised;

import unalcol.algorithm.Algorithm;
import unalcol.learn.Recognizer;
import unalcol.types.collection.Collection;

/**
 *
 * @author jgomez
 */
public abstract class UnsupervisedLearning<T> extends 
        Algorithm<Collection<T>, Recognizer<T>> {    
}

